<?php

define("base_url", "http://localhost/ugel/");
define("controller_default", "homeController");
define("action_default", "index");