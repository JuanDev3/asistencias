<?php

class homeController{
    public function index(){		
		require_once ('views/app-admin/usuarios/login.php');
 
    }
   

}