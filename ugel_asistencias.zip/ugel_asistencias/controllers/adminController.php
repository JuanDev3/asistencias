<?php
require_once 'models/mAdmin.php';
require_once 'helpers/utils.php';
class adminController{
	private $model;
	function __construct(){
		$this->model=new Admin();
	}
    public function login(){
		
		$email = htmlentities(addslashes($_POST['email']));  //para evitar sqlinjection
		$clave = htmlentities(addslashes($_POST['clave']));
		$codPerfil = htmlentities(addslashes($_POST['codPerfil']));	  
		
		$admin = new Admin();		
		$emailUser = $admin->emailExiste($email);
	
		if ($emailUser ==  TRUE){
			
		  //el email existe 
			$usuario = new Admin(); 
			$dato = $usuario->loginModel("usuario","u.email='$email' AND u.codPerfil= '$codPerfil'");					
			$claveUser = $usuario->claveExiste($clave,$email,$codPerfil);		
			 if($claveUser ==  TRUE ){
				 // iniciar session
				 $_SESSION["usuario"]=$dato['email'];				
				 $_SESSION["codigo"]=$dato['codUsuario'];
				 $_SESSION["perfil"] = $dato['nombrePerfil'];					 
				 
				 header("Location:".base_url.'admin/dashboard');
	
			 } else{
				 // su contraseña no es correcta
				 $_SESSION['error_login'] = 'Contraseña Incorrecta !!';
               
				 header("Location:".base_url.'home/index');
			 }  
		} else{
		  // email no existe		 
		   $_SESSION['error_login'] = 'Email Incorrecto !!';               
		   header("Location:".base_url.'home/index');
		}
		
    }

    public function dashboard(){      
		require_once ('views/app-admin/usuarios/dashboard.php');
	}	

    public function list(){	
		$admin = new Admin();
		$usuarios = $admin->getUsuarios();
        $responsable = $admin->getResponsable();
		require_once ('views/app-admin/usuarios/lista.php');
	}
    public function createUser(){
		if(isset($_POST)){
			$email = isset($_POST['emailCreate']) ? $_POST['emailCreate'] : false;
			$password = isset($_POST['claveCreate']) ? $_POST['claveCreate'] : false;
			$perfil = isset($_POST['perfilCreate']) ? $_POST['perfilCreate'] : false;
            $responsable = isset($_POST['responsableCreate']) ? $_POST['responsableCreate'] : false;
			
			if($email && $password && $perfil && $responsable){
				$admin = new Admin();
				$admin->setEmail($email);
				$admin->setClave($password);
				$admin->setCodPerfil($perfil);
				$admin->setCodEspecialistaResp($responsable);
				
				$save = $admin->saveUser();
				if($save){
					$_SESSION['register'] = "complete";
				}else{
					$_SESSION['register'] = "failed";
				}
			}else{
				$_SESSION['register'] = "failed";
			}
		}else{
			$_SESSION['register'] = "failed";
		}
		header("Location:".base_url.'admin/list');
	}
    
    public function updateUser(){       
        if(isset($_POST)){
            // Recoger datos form
            $codUser = $_POST['codUser'];
            $email = $_POST['emailUser'];
            $clave= $_POST['password'];   
			$estado= $_POST['estado'];        			
            
            // Upadate del pedido
            $admin = new Admin();
            $admin->setCodUsuario($codUser);
            $admin->setEmail($email);          
            $admin->setClave($clave);
			$admin->setEstado($estado);
    
            $admin->updateUsuario();							
            
            header("Location:".base_url.'admin/list');
        }else{
            header("Location:".base_url.'admin/dashboard');
            
        }
    } 

    
    public function deleteUser(){	
		
        if(isset($_POST)){    
			$codUser = $_POST['codUser2'];
			$admin = new Admin();
			$admin->setCodUsuario($codUser);
			
			$delete = $admin->deleteUsuario();
			if($delete){
				$_SESSION['delete'] = 'complete';
			}else{
				$_SESSION['delete'] = 'failed';
			}
		}else{
			$_SESSION['delete'] = 'failed';
            header("Location:".base_url.'admin/dashboard');
		}
		
		header('Location:'.base_url.'admin/list');
	}

	public function logout(){	
		
		if(isset($_SESSION['usuario'])){
			unset($_SESSION['usuario']);
			session_destroy();
		}
		
		header("Location:".base_url);
	}
	
	public function showPerfil(){		
		$codUsuario = $_SESSION["codigo"];
		$admin = new Admin();	
		$admin->setCodUsuario($codUsuario); 	
		$dataUser = $admin->registroNullExiste();

		if ($dataUser ==  TRUE){
			$admin = new Admin();	
			$admin->setCodUsuario($codUsuario); 	
			$dataUserPerfil = $admin->getPerfilUsuarioNullData();	
			require_once ('views/app-admin/usuarios/perfilUser.php');		

		}else if ($dataUser == false){
			$admin = new Admin();	
			$admin->setCodUsuario($codUsuario);
			$dataUserPerfil = $admin->getPerfilUsuariosNotnullData();
			require_once ('views/app-admin/usuarios/perfilUser2.php');
		}
		
	}

	public function updatePerfil(){
		if(isset($_POST)){
            // Recoger datos form
            $codUser = $_POST['cod'];
            $email = $_POST['email'];
            $clave= $_POST['claveUser'];          			
            
            // Upadate del pedido
            $admin = new Admin();
            $admin->setCodUsuario($codUser);
            $admin->setEmail($email);          
            $admin->setClave($clave);			
            $save = $admin->updatePerfilUsuarioNull();	
			if($save){
				$_SESSION['usuariou'] = "complete";
			}else{
				$_SESSION['usuariou'] = "failed";
			}		
			header("Location:".base_url.'admin/showPerfil');
        }else{
			$_SESSION['validar'] = 'No se encontraron datos !!';
            header("Location:".base_url.'admin/dashboard');
            
        }

	}
}