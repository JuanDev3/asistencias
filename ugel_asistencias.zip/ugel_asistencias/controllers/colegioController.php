<?php
require_once 'models/mColegio.php';
require_once 'helpers/utils.php';

class colegioController{
    private $model;
	function __construct(){
		$this->model=new Colegio();
	}
    public function list(){	
		$colegio = new Colegio();
		$colegios = $colegio->getColegios();
        $responsable = $colegio->getResponsable();
        //$region = $colegio->getRegion();
        //$provincia = $colegio->getProvincia();
        $distrito = $colegio->getDistrito();
		require_once ('views/app-admin/colegios/listaColegios.php');
	}

    public function createColegio(){
		if(isset($_POST)){
			$nomColegio = isset($_POST['nomColegio']) ? $_POST['nomColegio'] : false;
			$direccion = isset($_POST['direccion']) ? $_POST['direccion'] : false;
			$telefono = isset($_POST['telefono']) ? $_POST['telefono'] : false;
            $distrito = isset($_POST['distrito']) ? $_POST['distrito'] : false;
            $responsable = isset($_POST['responsableCreate']) ? $_POST['responsableCreate'] : false;
			
			if($nomColegio && $distrito && $responsable){
				$colegio = new Colegio();
				$colegio->setNomColegio($nomColegio);
				$colegio->setDireccion($direccion);
				$colegio->setTelefono($telefono);
				$colegio->setCodDistrito($distrito);
                $colegio->setCodEspecialistaResp($responsable);
				
				$save = $colegio->saveColegio();
				if($save){
					$_SESSION['register'] = "complete";
				}else{
					$_SESSION['register'] = "failed";
				}
			}else{
				$_SESSION['register'] = "failed";
			}
		}else{
			$_SESSION['register'] = "failed";
		}
		header("Location:".base_url.'colegio/list');
	}

    public function updateColegio(){       
        if(isset($_POST)){
            // Recoger datos form
            $codColegio = $_POST['codColegioUdpate'];
            $nomColegio = $_POST['nomColegioUdpate'];
            $direccion = $_POST['direccionUpdate'];
            $telefono= $_POST['telefonoUpdate'];   		       			
            
            // Upadate del pedido
            $colegio = new Colegio();
            $colegio->setCodColegio($codColegio);
            $colegio->setNomColegio($nomColegio);          
            $colegio->setDireccion($direccion);
			$colegio->setTelefono($telefono);
    
            $colegio->updateColegio();							
            
            header("Location:".base_url.'colegio/list');
        }else{
            header("Location:".base_url.'admin/dashboard');
            
        }
    } 

    public function deleteColegio(){	
		
        if(isset($_POST)){    
			$codColegio = $_POST['codColegioDelete'];
			$colegio = new Colegio();
			$colegio->setCodColegio($codColegio);
			
			$delete = $colegio->deleteColegio();
			if($delete){
				$_SESSION['delete'] = 'complete';
			}else{
				$_SESSION['delete'] = 'failed';
			}
		}else{
			$_SESSION['delete'] = 'failed';
            header("Location:".base_url.'colegio/colegio');
		}
		
		header('Location:'.base_url.'colegio/list');
	}


}