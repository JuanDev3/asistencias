
<?php require_once 'helpers/utils.php';
require_once 'views/layouts/header.php';?>
        <script type="text/javascript">
                        function validar(e) { // 1
                        tecla = (document.all) ? e.keyCode : e.which; // 2
                        if (tecla==8) return true; // 3
                        patron =/[A-Za-z\s]/; // 4
                        te = String.fromCharCode(tecla); // 5
                        return patron.test(te); // 6
                        }


        </script>
        <script type="text/javascript">
            $(document).ready( function () {
                $('#colegiot').DataTable();
            } );
        </script>

<!-- Page Content -->
<div id="content" class="bg-grey w-100">

<section class="bg-light py-3">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-md-7">
              <h3 class="font-weight-bold mb-0">Usuarios</h3><br>          
              <h5 class="lead text-muted">Información de usuarios y su gestión</h5>
            </div>
            <div class="col-lg-3 col-md-4 d-flex mt-3 ml-1">                          
                <button type="button" class="btn btn-primary w-100 align-self-center" data-backdrop="false"
                    data-toggle="modal" data-target="#modalCreate"><i class="fas fa-user-plus"></i> Nuevo usario</button>
                     <!-- Modal para nuevo registro -->

                     <div class="modal fade" id="modalCreate" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitlex" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered" role="document">
                                                    <div class="modal-content">
                                                    <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLongTitle"> Nuevo usuario</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                                </button>
                                                    </div>
                                                    <div class="modal-body">
                                                  
                                                        <form action="<?=base_url?>admin/createUser" method="POST">                                        

                                                            <label>Email</label>
                                                            <input type="email" name="emailCreate" id="emailCreate" class="form-control input-sm" maxlength="50" placeholder="midireccion@gmail.com" required>
                                                            <label>Clave</label>
                                                            <input type="password" name="claveCreate" id="claveCreate" class="form-control input-sm" required>                                                         
                                                            <label for="perfilCreate">Perfil</label>                                             
                                                                <select class="form-control input-sm" name="perfilCreate" id="perfilCreate" required>
                                                                    <option selected>Seleccione perfil</option>
                                                                    <option value="1">Administrador</option>
                                                                    <option value="2">Director</option>
                                                                    <option value="3">Responsable</option>
                                                                </select>
                                                            <label for ="responsableCreate">Responsable</label>      
                                                                <select class="form-control" name="responsableCreate" id="responsableCreate" required> 
                                                                    <option value="NULL">-- Seleccione responsable--</option> 
                                                                    <?php while ($row=$responsable->FETCH(PDO::FETCH_ASSOC)) { ?>
                                                                    <option value="<?php echo $row['codEspecialistaResp'] ?>"><?php echo $row['responsable'] ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                          

                                                            <div class="modal-footer">
                                                                <button type="submit" class="btn btn-primary col-md-6 align-self-center"><i class="fas fa-check-circle"></i> Guardar</button>
                                                             </div>
                                                             
                                                        </form> 
                                                    </div>
                                                    
                                                    </div>
                                                </div>
                                                </div>
                                                <!-- fin del modal -->

            </div>
        </div>
    </div>
</section>

<section class="bg-mix py-3">
  <div class="container">
      <div class="card rounded-1 shadow">
          <div class="card-body">
          <div class="table-responsive">
                      <table class="table table-striped" id="colegiot">
                        <thead>
                          <tr>                            
                            <th class="text-center">Cod</th>                           
                            <th class="text-center">Email</th>
                            <th hidden class="text-center">Clave</th>
                            <th class="text-center">Perfil</th>     
                            <th class="text-center">Estado</th>                      
                            <th class="text-center">Acciones</th>
                          </tr>
                        </thead>
                        <tbody>                           
                                <?php foreach( $usuarios as $key => $value ) {
                                    foreach($value as $va){ ?>

                                <?php $datos = $va['codUsuario']."||".
                                                $va['email']."||".  
                                                $va['clave']."||".   
                                                $va['nomPerfil']."||".                                            
                                                $va['estado']; ?>
                                <tr>
                                    <td class="text-center"><?=$va['codUsuario'];?></td>
                                    <td class="text-center"><?= $va['email'];?></td>                                 
                                    <td hidden class="text-center"><?= $va['clave'];?></td>
                                    <td class="text-center"><?=$va['nomPerfil'];?></td>   
                                  
                                    <?php if ( $va['estado']  == '1') { ?>
                                        <td class="text-center"><i class="fas fa-check-circle"></i></td> 
                                        <?php } else { ?>
                                        <td class="text-center"><i class="fas fa-check-circle text-danger"></i></td>
                                    <?php } ?>                            
                                                          
                                    
                                    <td class="text-center">                                        
                                        <button class="btn btn-primary" data-backdrop="false"
                                            data-toggle="modal" data-target="#modalEdicion"
                                             onclick="agregaform('<?php echo $datos ?>')"><i class="fas fa-pencil-alt"></i></button>
                                        <button class="btn btn-danger" data-backdrop="false" 
                                        data-toggle="modal" data-target="#modalEliminar"
                                             onclick="agregaform2('<?php echo $datos ?>')"><i class="far fa-trash-alt "></i></button>                                      
                                        
                                    </td>

                                    <div class="modal fade" id="modalEliminar" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered" role="document">
                                                    <div class="modal-content">
                                                    <div class="modal-header">                                                            
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                                </button>
                                                    </div>
                                                    <div class="modal-body">   
                                                        <div class="container mb-4 text-center">
                                                            <img src="<?=base_url?>/views/assets/img/alarma.png" alt="" class="logo">                           
                                                        </div>   
                                                        <h3>¿Está seguro de que desea borrar el registro? </h3>                                               
                                                        <form action="<?=base_url?>admin/deleteUser" method="POST"> 
                                                            <label hidden>COD</label>
                                                            <input hidden type="text" id="codUser2" name="codUser2">  
                                                            <div class="modal-footer">                                                                                                                     
                                                                <button type="submit" class="btn btn-danger"><i class="far fa-trash-alt"></i> Eliminar</button>
                                                             </div>
                                                             
                                                        </form> 
                                                    </div>
                                                    
                                                    </div>
                                                </div>
                                                </div>

                                             <!-- Modal para edicion de datos -->

                                            <div class="modal fade" id="modalEdicion" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered" role="document">
                                                    <div class="modal-content">
                                                    <div class="modal-header">

                                                            <h5 class="modal-title" id="exampleModalLongTitle">Actualizar Datos</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                                </button>
                                                    </div>
                                                    <div class="modal-body">
                                                  
                                                        <form action="<?=base_url?>admin/updateUser" method="POST"> 
                                                            <label hidden>COD</label>
                                                            <input hidden type="text" id="codUser" name="codUser">  

                                                            <label>Email</label>
                                                            <input type="text" name="emailUser" id="emailUser" class="form-control input-sm">
                                                            <label>Clave</label>
                                                            <input type="password" name="password" id="password" class="form-control input-sm">                                                         
                                                            <label>Perfil</label>
                                                            <input type="text" name="perfilUser" id="perfilUser" class="form-control input-sm" disabled>
                                                            <label class="font-weight-bold" for="estado">Estado</label>
                                                                <select class="form-control" id="estado" name="estado">  
                                                                    <option value="1"<?=isset($va['estado']) && is_object($va['estado']) && $va['estado']->estado == "1" ? 'selected' : '';?>>Activo</option>
                                                                    <option value="0"<?=isset($va['estado']) && is_object($va['estado']) && $va['estado']->estado == "0" ? 'selected' : '';?>>Inactivo</option>                                        
                                                                </select>

                                                            <div class="modal-footer">
                                                                <button type="submit" class="btn btn-primary col-md-6 align-self-center"><i class="fas fa-check-circle"></i> Actualizar</button>
                                                             </div>
                                                             
                                                        </form> 
                                                    </div>
                                                    
                                                    </div>
                                                </div>
                                                </div>
                                                <!-- fin del modal -->
                                                      
                                                        <script>
                                                        
                                                                function agregaform(datos){

                                                                d=datos.split('||');

                                                                $('#codUser').val(d[0]);                                                                
                                                                $('#emailUser').val(d[1]);
                                                                $('#password').val(d[2]);    
                                                                $('#perfilUser').val(d[3]);                                                           
                                                                $('#estado').val(d[4]);
                                                                }
                                                                function agregaform2(datos){

                                                                    d=datos.split('||');

                                                                    $('#codUser2').val(d[0]);                                                                
                                                                    $('#emailUser2').val(d[1]);
                                                                    $('#password2').val(d[2]);                                                               
                                                                    $('#perfilUser').val(d[3]);
                                                                    }
                                                        </script>     
                                </tr>
                                <?php }
                             }?>                         
                        </tbody>

                      </table>
                    </div>

              
          </div>
      </div>
  </div>
</section>
<section class="bg-mix py-3">
<h1></h1>
</section><br>

</div>

<!--FIN content-->


<?php  require_once 'views/layouts/footer.php'; ?>

