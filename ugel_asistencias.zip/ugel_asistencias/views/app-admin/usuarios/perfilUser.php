
<?php require_once 'helpers/utils.php';
require_once 'views/layouts/header.php';?>
        <script type="text/javascript">
                        function validar(e) { // 1
                        tecla = (document.all) ? e.keyCode : e.which; // 2
                        if (tecla==8) return true; // 3
                        patron =/[A-Za-z\s]/; // 4
                        te = String.fromCharCode(tecla); // 5
                        return patron.test(te); // 6
                        }

        </script>
        <script type="text/javascript">          
        </script>
<!-- Page Content -->
<div id="content" class="bg-grey w-100">
    <section class="bg-light py-3">
        <div class="container">
            <div class="row">
                <div class="col-lg-9 col-md-7">               
                <h3 class="font-weight-bold mb-0">Mi Perfil </h3>   
                <h5 class="lead text-muted">Actualiza la informacion de tu perfil</h5>
                </div>                
            </div>
        </div>
    </section>
    <section class="bg-mix py-3">
        <div class="container">
            <div class="card rounded-1 shadow">
                <div class="card-body">
                    <form class="p-3" action="<?=base_url?>admin/updatePerfil" method="POST">          
                        <div class="form-row">
                            <input hidden class="form-control" type="text" name="cod" id="cod" 
                            maxlength="50" value="<?=isset($dataUserPerfil) && is_object($dataUserPerfil) ? $dataUserPerfil->codigoUser: ''; ?>" />
                                <div class="form-group col-md-4 col-12">
                                    <label class="font-weight-bold" for="email">Email</label>
                                    <input class="form-control" type="email" id="email" name="email" maxlength="45"                         
                                    value="<?=isset($dataUserPerfil) && is_object($dataUserPerfil) ? $dataUserPerfil->emailUser : ''; ?>" required/>
                                </div>
                            <div class="form-group col-md-4 col-12">
                                <label class="font-weight-bold" for="claveUser">Clave</label>                                      
                                <input class="form-control" type="password" id="claveUser" name="claveUser" maxlength="20"                          
                                value="<?=isset($dataUserPerfil) && is_object($dataUserPerfil) ? $dataUserPerfil->claveUser : ''; ?>" required/>						
                            </div>
                            <div class="form-group  col-md-4 col-12">
                                <label class="font-weight-bold" for="perfil">Perfil</label>                                      
                                <input class="form-control" type="text" id="perfil" name="perfil"                          
                                value="<?=isset($dataUserPerfil) && is_object($dataUserPerfil) ? $dataUserPerfil->perfilUser  : ''; ?>" disabled/>	
                            </div>                            
                            <div class="form-group col-md-4 col-12">
                                <label class="font-weight-bold" for="estado">Estado</label>
                                <select class="form-control" id="estado" name="estado" disabled>  
                                    <option value="1"<?=isset($dataUserPerfil) && is_object($dataUserPerfil) && $dataUserPerfil->estadoUser == "1" ? 'selected' : '';?>>Activo</option>
                                    <option value="0"<?=isset($dataUserPerfil) && is_object($dataUserPerfil) && $dataUserPerfil->estadoUser == "0" ? 'selected' : '';?>>Inactivo</option>                                        
                                </select>   						
                            </div>               
        
                        </div>
                        <div class="text-right">
                            <button type="submit" class="btn btn-primary col-md-4 col-12 align-self-center"><i class="fas fa-check-circle"></i> Actualizar</button>
                        </div>
                    </form>     
                                    
                </div>
            </div>
        </div>
    </section>
    <section class="bg-mix py-3">
    <h1></h1>
    </section><br>
</div>

<!--FIN content-->

<?php  require_once 'views/layouts/footer.php'; ?>

