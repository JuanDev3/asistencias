<?php require_once 'helpers/utils.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>UGEL Login</title>
    <link rel="stylesheet" href="<?=base_url?>views/assets/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="<?=base_url?>views/assets/css/styles.css">
</head>
<body>    
    <div class="container-fluid"> 
        <div class="row justify-content-center">
            <div class="col-md d-none d-sm-none d-md-block img-login">
                <div class="container container-login100">
                </div>
            </div>
            <div class="col-md-6 ">
                <div class="container-login100">
                    <form class="text-center p-5" action="<?=base_url?>admin/login" method="POST" >    
                                                 
                        <div class="container mb-4 text-center">
                            <img src="<?=base_url?>/views/assets/img/logo.png" alt="" class="logo">                           
                        </div>                                 
                        <div class="mb-3">
                            <label for="email" class="form-label"> </label>                            
                            <input placeholder="Ingrese email" name="email" type="email" class="form-control" id="email" aria-describedby="emailHelp" required>                                                         
                        </div>
                        <div class="input-group mb3" required>
                            <select class="form-select" id="codPerfil" name="codPerfil" required>
                                <option selected>Seleccione perfil</option>
                                <option value="1">Administrador</option>
                                <option value="2">Director</option>
                                <option value="3">Responsable</option>
                            </select>
                        </div> 
                        <div class="mb-3">
                            <label for="clave" class="form-label"></label>
                            <input placeholder="Ingrese contraseña" name="clave" type="password" class="form-control" id="clave" required>
                        </div>  
                        <div class="d-grid gap-2 col-12 mx-auto">        
                            <button  class="btn btn-primary btn-block my-4 shadow" type="submit" name="" value="">Iniciar sesión</button>
                        </div> 
                                <?php if(isset($_SESSION['error_login']) ): ?>
                                <strong class="text-center text-danger"><?=$_SESSION['error_login']?></strong>
                                <?php endif; ?>
                                <?php Utils::deleteSession('error_login'); ?>                            
                                <hr>                    
                                    <p class="text-center text-primary"><a class="text-primary" href="/inicio/registro/"> </a>  <a class="text-primary" href="/inicio/recovery_password/">¿Olvidaste tu contraseña?</a> </p>
                     </form> 
                     <div class="container-fluid">
                        <div class="row mt-1">                   
                            <div class="col-md-12">
                                <p class="text-center">© UGEL Sechura 2021</p>
                            </div>
                        </div>
                    </div>                     
                      
                </div>
            </div>              
         </div>    
    </div>

    <script src="<?=base_url?>views/assets/js/jquery-3.6.0.min.js"></script>   
    <script src="<?=base_url?>views/assets/js/popper.min.js"></script>
    <script src="<?=base_url?>views/assets/js/bootstrap.min.js"></script>
  
</body>
</html>
