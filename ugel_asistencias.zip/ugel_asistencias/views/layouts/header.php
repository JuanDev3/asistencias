<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?=base_url?>views/assets/bundles/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?=base_url?>views/assets/jquery.dataTables.min.css">

   

    <!-- Styles -->
    <link rel="stylesheet" href="<?=base_url?>views/assets/css/styles.css">
    <script src="<?=base_url?>views/assets/js/jquery-3.6.0.min.js"></script>  
    <script src="<?=base_url?>views/assets/bundles/jquery/jquery.min.js"></script>  
   
    <!-- Google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,700&display=swap" rel="stylesheet">

    <!-- Ionic icons -->
    <link href="https://unpkg.com/ionicons@4.5.10-0/dist/css/ionicons.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.7.0/css/all.css">

    <title>UGEL - Asistencias</title>
</head>

<body>
    <div class="d-flex" id="content-wrapper">

        <!-- Sidebar -->
        <div id="sidebar-container" class="bg-primary">
            <div class="logo">
                <h5 mt-2> <a class="text-light font-weight-bold mb-0 text-center" href="<?= base_url ?>admin/dashboard"> UGEL - Asistencias</a> </h5>
            </div>
            <div class="menu">         
                <a href="<?= base_url ?>admin/list" class="d-block text-light p-3 border-0"><i class="fas fa-user-friends lead mr-2"></i>
                    Usuarios</a>
                <a href="<?= base_url ?>colegio/list" class="d-block text-light p-3 border-0"><i class="fas fa-university lead mr-2"></i>
                    Colegios</a>
                <a href="<?= base_url ?>Nivel/list" class="d-block text-light p-3 border-0"><i class="fas fa-graduation-cap mr-1"></i>
                    Niveles</a>
                <a href="<?= base_url ?>colenivel/list" class="d-block text-light p-3 border-0"><i class="fas fa-layer-group mr-1"></i>
                    Colegios por nivel</a>
                <a href="<?= base_url ?>repartidor/list" class="d-block text-light p-3 border-0"><i class="fas fa-user-tie lead mr-1"></i></i>
                   Responsables</a>
                <a href="<?= base_url ?>encargado/list" class="d-block text-light p-3 border-0"><i class="fas fa-clipboard-list lead mr-2"></i>
                    Asistencias</a>
                <a href="<?= base_url ?>tienda/list" class="d-block text-light p-3 border-0"><i class="fas fa-chart-pie lead mr-2"></i>
                    Reportes</a>
                <a href="<?= base_url ?>mercado/list" class="d-block text-light p-3 border-0"><i class="fas fa-question-circle lead mr-2"></i>
                   Soporte</a>

                
            </div>
        </div>
        <!-- Fin sidebar -->

        <!-- Page  -->
        <div id="page-content-wrapper" class="w-100 bg-light-blue">

            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom shadow">
                <div class="container">
                    <a class="text-primary" id="menu-toggle"><i class="fas fa-bars"></i></a>                   
                    <div class=" text-right float-right">                       
                                                     
                        <li class="nav-item dropdown text-right float-right" style="list-style:none;">
                            <a class="nav-link text-dark dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="<?=base_url?>/views/assets/img/logo.ico" class="img-fluid avatar mr-2"
                                    alt="" />
                                    <?php
                                    ?>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?= base_url?>admin/showPerfil" ><i class="fas fa-user"></i>  Mi perfil</a>                    
                                       
                                <div class="dropdown-divider"></div>
                                <a href="<?= base_url ?>/admin/logout" class="dropdown-item"><i class="fas fa-sign-out-alt"></i> Salir</a>
                            </div>
                        </li>
                           
                    </div>

                </div>
            </nav>
            <!-- Fin Navbar -->