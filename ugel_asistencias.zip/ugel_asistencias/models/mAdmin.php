<?php
require_once 'config/db.php';
class Admin{
    private $codUsuario;
    private $email;
    private $clave;
    private $codPerfil;
    private $codEspecialistaResp;
    private $estado;
    private $db;	
    public function __construct(){
        $this -> usuariosA = array();
        $this -> responsableA = array();
        $this ->db = Database::StartUp();       
    }

    function getCodUsuario(){
        return $this -> codUsuario;
    }
    function getEmail(){
        return $this -> email;
    }
    function getClave(){        
       return $this -> clave;
    }
    function getCodPerfil(){
        return $this -> codPerfil;
    }
    function getCodEspecialistaResp(){
        return $this -> codEspecialistaResp;
    }
    function getEstado(){
        return $this -> estado;
    }

    function setCodUsuario($codUsuario){
        $this -> codUsuario= $codUsuario;
    }
    function setEmail($email){
		$this->email = $this->db->quote($email);
	}
    function setClave($clave){
		$this->clave = $clave;
	}
    function setCodPerfil($codPerfil){
		$this->codPerfil = $codPerfil;
	}
    function setCodEspecialistaResp($codEspecialistaResp){
		$this->codEspecialistaResp = $codEspecialistaResp;
	}
    function setEstado($estado){
		$this->estado = $estado;
	}

    public function loginModel($tabla, $condicion){
        $consulta ="SELECT codUsuario,email,clave,u.codPerfil as perfilU,codEspecialistaResp,estado,p.nomPerfil as nombrePerfil FROM $tabla u INNER JOIN perfil p ON u.codPerfil=p.codPerfil WHERE $condicion ";
        $resultado = $this->db->query($consulta);
        $filas=$resultado->FETCH(PDO::FETCH_ASSOC);    
        return $filas;      
    }
    public function emailExiste($email){
        $consulta ="SELECT COUNT(codUsuario) FROM usuario WHERE email = '$email' AND estado = 1 LIMIT 1 ;";
        $resultado = $this->db->query($consulta);
        $total = $resultado->fetch(PDO::FETCH_BOTH)[0];
    
        if($total > 0){
          return true;
       }else{
          return false;
       }        
      }

    public function claveExiste($clave,$email,$codPerfil){
        $consulta ="SELECT COUNT(codUsuario) FROM usuario WHERE clave = '$clave' AND email = '$email' AND codPerfil='$codPerfil' LIMIT 1 ;";
        $resultado = $this->db->query($consulta);
        $total = $resultado->fetch(PDO::FETCH_BOTH)[0];
    
        if($total > 0){
          return true;
       }else{
          return false;
       }        
      }
     
    public function getUsuarios(){
        $usuarios = $this->db->query("SELECT u.codUsuario,u.email,u.clave,u.estado,p.nomPerfil FROM usuario u INNER JOIN perfil p ON u.codPerfil=p.codPerfil WHERE u.estado = '1' ORDER BY codUsuario DESC");
		while($filas=$usuarios->FETCHALL(PDO::FETCH_ASSOC)){
			$this->usuariosA[]=$filas;
			   }
			   return $this->usuariosA;
		return $usuarios;
	}
    public function getResponsable(){
        $responsable = $this->db->query("SELECT codEspecialistaResp, concat_ws(' ', nomEspecialistaResp, apellidosEspecialistaResp)as responsable FROM especialistaresp WHERE 1");		
        return $responsable;
    }

    public function saveUser(){
		$sql = "INSERT INTO usuario VALUES(NULL,{$this->getEmail()},'{$this->getClave()}',{$this->getCodPerfil()},{$this->getCodEspecialistaResp()},1);";
		$save = $this->db->query($sql);		
		$result = false;
		if($save){
			$result = true;
		}
		return $result;
	}
    
    public function updateUsuario(){
		$sql = "UPDATE usuario u SET u.email ={$this->getEmail()},u.clave='{$this->getClave()}',u.estado={$this->getEstado()} WHERE u.codUsuario={$this->getCodUsuario()};";
		$save = $this->db->query($sql);		
		$result = false;
		if($save){
			$result = true;
		}
		return $result;	
	}

    public function deleteUsuario(){
		$sql = "UPDATE usuario SET estado = '0' WHERE codUsuario={$this->getCodUsuario()}";
		$delete = $this->db->query($sql);		
		$result = false;
		if($delete){
			$result = true;
		}
		return $result;
	}

    public function registroNullExiste(){
        $consulta ="SELECT COUNT(*) FROM usuario WHERE codEspecialistaResp is NULL AND codUsuario = {$this->getCodUsuario()};";
        $resultado = $this->db->query($consulta);
        $total = $resultado->fetch(PDO::FETCH_BOTH)[0];    
        if($total == 1){
          return true;
       }else{
          return false;
       }        
      }

      public function getPerfilUsuariosNotnullData(){
        $usuarios = $this->db->query("SELECT u.codUsuario as codigoUser,u.email as emailUser,u.clave as claveUser,p.nomPerfil as perfilUser, e.nomEspecialistaResp as nomEspecialista,e.apellidosEspecialistaResp as apEspecialista,u.estado as estadoUser
        FROM usuario u INNER JOIN perfil p ON u.codPerfil=p.codPerfil INNER JOIN especialistaresp e ON u.codEspecialistaResp = e.codEspecialistaResp      
        WHERE u.codEspecialistaResp is not NULL AND u.codUsuario = {$this->getCodUsuario()}");
        
		return $usuarios->fetchObject();
    }
    
    public function getPerfilUsuarioNullData(){
        $usuarios = $this->db->query("SELECT u.codUsuario as codigoUser,u.email as emailUser,u.clave as claveUser,p.nomPerfil as perfilUser,u.estado as estadoUser
        FROM usuario u INNER JOIN perfil p ON u.codPerfil=p.codPerfil WHERE u.codUsuario = {$this->getCodUsuario()}");
        
		return $usuarios->fetchObject();
    }

    public function updatePerfilUsuarioNull(){
        $sql = "UPDATE usuario u SET u.email ={$this->getEmail()},u.clave='{$this->getClave()}' WHERE u.codUsuario={$this->getCodUsuario()};";
		$save = $this->db->query($sql);		
		$result = false;
		if($save){
			$result = true;
		}
		return $result;	
    }



}