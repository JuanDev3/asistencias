<?php
require_once 'config/db.php';

class Colegio{
    private $codColegio;
    private $nomColegio;
    private $direccion;
    private $telefono;
    private $codDistrito;
    private $codEspecialistaResp;
    private $db;	
    public function __construct(){
        $this -> colegiosA = array();
        $this -> responsableA = array();
        $this ->db = Database::StartUp();       
    }
    function getCodColegio(){
        return $this -> codColegio;
    }
    function getNomColegio(){
        return $this -> nomColegio;
    }
    function getDireccion(){
        return $this -> direccion;
    }
    function getTelefono(){
        return $this -> telefono;
    }
    function getCodDistrito(){
        return $this -> codDistrito;
    }
    function getCodEspecialistaResp(){
        return $this -> codEspecialistaResp;
    }
 
    function setCodColegio($codColegio){
        $this -> codColegio = $codColegio;
    }
    function setNomColegio($nomColegio){
        $this -> nomColegio = $nomColegio;
    }
    function setDireccion($direccion){
        $this -> direccion = $direccion;
    }
    function setTelefono($telefono){
        $this -> telefono = $telefono;
    }
    function setCodDistrito($codDistrito){
        $this -> codDistrito = $codDistrito;
    }

    function setCodEspecialistaResp($codEspecialistaResp){
		$this->codEspecialistaResp = $codEspecialistaResp;
	}

    public function getColegios(){
        $colegios = $this->db->query("SELECT c.codColegio, c.nomColegio,c.direccion,c.telefono,c.codDistrito ,d.nomDistrito,p.nomProvincia as prov,concat_ws(' ', e.nomEspecialistaResp, e.apellidosEspecialistaResp)as responsable FROM colegio c 
        INNER JOIN distrito d ON c.codDistrito = d.codDistrito 
        INNER JOIN especialistaresp e ON c.codEspecialistaResp=e.codEspecialistaResp  
        INNER JOIN provincia p ON d.codProvincia = p.codProvincia
        WHERE estado = 1 ORDER BY c.codColegio ASC");
		while($filas=$colegios->FETCHALL(PDO::FETCH_ASSOC)){
			$this->colegiosA[]=$filas;
			   }
			   return $this->colegiosA;
		return $colegios;
	}
    public function getResponsable(){
        $responsable = $this->db->query("SELECT codEspecialistaResp, concat_ws(' ', nomEspecialistaResp, apellidosEspecialistaResp)as responsable FROM especialistaresp WHERE 1");		
        return $responsable;
    }
    public function getDistrito(){
        $distrito = $this ->db ->query("SELECT * FROM distrito WHERE 1 ");
        return $distrito;
    }

    public function saveColegio(){
        $sql = "INSERT INTO colegio VALUES(NULL,'{$this->getNomColegio()}','{$this->getDireccion()}','{$this->getTelefono()}',{$this->getCodDistrito()},{$this->getCodEspecialistaResp()},1);";
		$save = $this->db->query($sql);		
		$result = false;
		if($save){
			$result = true;
		}
		return $result;
    }

    public function updateColegio(){
        $sql = "UPDATE colegio SET nomColegio ='{$this->getNomColegio()}',direccion='{$this->getDireccion()}',telefono='{$this->getTelefono()}' WHERE codColegio={$this->getCodColegio()};";
		$save = $this->db->query($sql);		
		$result = false;
		if($save){
			$result = true;
		}
		return $result;	
    }

    public function deleteColegio(){
        $sql = "UPDATE colegio SET estado = '0' WHERE codColegio={$this->getCodColegio()}";
		$delete = $this->db->query($sql);		
		$result = false;
		if($delete){
			$result = true;
		}
		return $result;
    }
}